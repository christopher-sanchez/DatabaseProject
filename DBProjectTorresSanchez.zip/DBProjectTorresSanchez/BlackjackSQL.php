<?php
header("Content-Type: application/json");
$action = $_POST['action'] ?? null;

$conn = new mysqli("127.0.0.1", "root", "", "blackjackdata2");

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed."]));
}

$response = ["success" => false];

switch ($action) {
    case "signup":
        $username = $_POST['username'];
        $age = $_POST['age'];
        $stmt = $conn->prepare("INSERT INTO users (username, userage, coins) VALUES (?, ?, 1000)");
        $stmt->bind_param("si", $username, $age);
        $response["success"] = $stmt->execute();
        break;

    case "login":
        $username = $_POST['username'];
        $stmt = $conn->prepare("SELECT coins FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $response = ["success" => true, "coins" => $row['coins']];
        }
        break;

    case "saveCoins":
        $username = $_POST['username'];
        $coins = $_POST['coins'];
        $stmt = $conn->prepare("UPDATE users SET coins = ? WHERE username = ?");
        $stmt->bind_param("is", $coins, $username);
        $response["success"] = $stmt->execute();
        break;

    case "leaderboard":
        $result = $conn->query("SELECT username, coins FROM users ORDER BY coins DESC LIMIT 10");
        $leaderboard = [];
        while ($row = $result->fetch_assoc()) {
            $leaderboard[] = $row;
        }
        $response = ["success" => true, "leaderboard" => $leaderboard];
        break;
}

echo json_encode($response);
$conn->close();
?>

